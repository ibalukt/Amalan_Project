﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;

namespace BookStore.Domain.Entities
{
    public class Book
    {
        [HiddenInput(DisplayValue = false)]
        public int Id { get; set; }
        [Required(ErrorMessage ="Please enter a product name")]
        public string Name { get; set; }

        [Required(ErrorMessage = "Please enter a category")]
        public string Category { get; set; }

        [DataType(DataType.MultilineText)]
        [Required(ErrorMessage = "Please enter a description")]
        public string Description { get; set; }

        [Required(ErrorMessage = "Please enter an ISBN")]
        public string ISBN { get; set; }

        [Required(ErrorMessage = "Please enter a publisher")]
        public string Publisher { get; set; }

        [Required(ErrorMessage = "Please enter a publication date")]
        public DateTime PublicationDate { get; set; }

        [Required(ErrorMessage = "Please enter a price")]
        public decimal Price { get; set; }

        public string Image { get; set; }
    }
}
