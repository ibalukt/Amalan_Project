﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BookStore.Domain.Abstract;
using BookStore.Domain.Entities;
using BookStore.WebUI.Models;

namespace BookStore.WebUI.Controllers
{
    public class BookController : Controller
    {
        private IBookRepository myrepository;
        // GET: Product
        public BookController (IBookRepository bookRepository)
        {
            this.myrepository = bookRepository;
        }

        public int PageSize = 6;
        public ViewResult List(string category,int page = 1)
        {
            BooksListViewModel model = new BooksListViewModel
            {
                Books = myrepository.Books.Where(p => category == null || p.Category == category)
                                          .OrderBy(p => p.Id).Skip((page - 1) * PageSize).Take(PageSize),

                PagingInfo = new PagingInfo
                {
                    CurrentPage = page,
                    ItemsPerPage = PageSize,
                    TotalItems = category == null ?
                                  myrepository.Books.Count() :
                                  myrepository.Books.Where
                                  (e => e.Category == category).Count()
                },
                CurrentCategory = category
            };
            return View(model);

        }

        public FileContentResult GetImage(int Id)
        {
            Book book = myrepository.Books.FirstOrDefault(p => p.Id == Id);

            if (book != null)
            {
                return File(book.ImageData, book.Image);
            }
            else
            {
                return null;
            }
        }
    }
}