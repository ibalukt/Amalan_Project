﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookStore.Domain.Entities
{
    public class CartLine
    {
        public Book Book { get; set; }
        public int Quantity { get; set; }
    }
    public class Cart
    {
        private List<CartLine> lineCollection = new List<CartLine>();

        public IEnumerable<CartLine> Lines
        {
            get { return lineCollection; }
        }

        public void AddItem(Book mybook, int myquantity)
        {
            CartLine line = lineCollection
                                .Where(p => p.Book.Id == mybook.Id)
                                .FirstOrDefault();

            if (line == null)
            {
                lineCollection.Add(new CartLine
                {
                    Book = mybook,
                    Quantity = myquantity
                });
            }

            else
            {
                line.Quantity += myquantity;
            }
        }

        public void RemoveLine(Book mybook)
        {
            lineCollection.RemoveAll(l => l.Book.Id == mybook.Id);
        }

        public decimal ComputeTotalValue()
        {
            return lineCollection.Sum(e => e.Book.Price * e.Quantity);
        }

        public void Clear()
        {
            lineCollection.Clear();
        }
    }
}
