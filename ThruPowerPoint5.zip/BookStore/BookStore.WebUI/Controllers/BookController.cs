﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BookStore.Domain.Abstract;
using BookStore.WebUI.Models;

namespace BookStore.WebUI.Controllers
{
    public class BookController : Controller
    {
        private IBookRepository myrepository;
        // GET: Product
        public BookController (IBookRepository bookRepository)
        {
            this.myrepository = bookRepository;
        }

        public int PageSize = 6;
        public ViewResult List(string category,int page = 1)
        {
            BooksListViewModel model = new BooksListViewModel
            {
                Books = myrepository.Books.Where(p => category == null || p.Category == category)
                                          .OrderBy(p => p.Id).Skip((page - 1) * PageSize).Take(PageSize),

                PagingInfo = new PagingInfo
                {
                    CurrentPage = page,
                    ItemsPerPage = PageSize,
                    TotalItems = myrepository.Books.Count()
                },
                CurrentCategory = category
            };
            return View(model);

        }
    }
}