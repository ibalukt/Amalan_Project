﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BookStore.Domain.Abstract;
using BookStore.Domain.Entities;

namespace BookStore.Domain.Concrete
{
    public class EFBookRepository : IBookRepository
    {
        public EFDbContext context = new EFDbContext();

        public IEnumerable<Book> Books
        {
            get { return context.Books; }
        }

        public void SaveBook(Book book)
        {
            if(book.Id == 0)
            {
                context.Books.Add(book);
            }
            else
            {
                Book dbEntry = context.Books.Find(book.Id);

                if (dbEntry != null)
                {
                    dbEntry.Name = book.Name;
                    dbEntry.Category = book.Category;
                    dbEntry.Description = book.Description;
                    dbEntry.ISBN = book.ISBN;
                    dbEntry.Publisher = book.Publisher;
                    dbEntry.PublicationDate = book.PublicationDate;
                }
            }
            context.SaveChanges();
        }
    }
}
